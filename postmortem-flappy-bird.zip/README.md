Este é um artigo referente ao postmortem de um dos jogos mais polêmicos e icônicos deste século: Flappy Bird.

Este artigo segue o padrão definido pela SBGames para artigos resumidos (http://www.sbgames.org/sbgames2015/#/trilhas/computacao)

Autores:
	Fernando L. Souza
	Lucas C. Medeiros
	Marcos F. Parreiras

